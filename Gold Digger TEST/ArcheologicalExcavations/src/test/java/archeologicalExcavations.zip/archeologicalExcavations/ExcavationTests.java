package archeologicalExcavations;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ExcavationTests {
    private Archaeologist Pesho;
    private Archaeologist Ivan;
    private Excavation excavation;
    @Before
    public void setup(){
         Pesho = new Archaeologist("Pesho",44);
         Ivan = new Archaeologist("Ivan",32);
         excavation = new Excavation("Varna",10);
    }
    @Test
    public void tstConstructor() {
        Excavation excavation = new Excavation("Varna",10);
        Assert.assertEquals("Varna",excavation.getName());
        Assert.assertEquals(10,excavation.getCapacity());
        Assert.assertEquals(0,excavation.getCount());

    }
    @Test(expected = NullPointerException.class)
    public void testConstructorShouldThrowWithEmptyName() {
        new Excavation(null,10);
    }
    @Test(expected = NullPointerException.class)
    public void testConstructorShouldThrowWithWrongName() {
        new Excavation("    ", 10);
    }
    @Test(expected = IllegalArgumentException.class)
    public void testConstructorShouldThrowWithNegativeCapacity() {
        new Excavation("Pernik",-5);

}
       @Test
    public void testAddArcheologist(){
        Excavation excavation = new Excavation("Pernik",10);
        excavation.addArchaeologist(Pesho);
        Assert.assertEquals(1,excavation.getCount());
        excavation.addArchaeologist(Ivan);
        Assert.assertEquals(2,excavation.getCount());
       }
       @Test(expected = IllegalArgumentException.class)
    public void testShouldThrowExceptionForNoCapacity() {
        Excavation excavation = new Excavation("Pernik",0);
        excavation.addArchaeologist(Pesho);
       }
    @Test(expected = IllegalArgumentException.class)
    public void testShouldThrowExceptionForArchaelogistExist() {
        excavation.addArchaeologist(Pesho);
        excavation.addArchaeologist(Pesho);
    }
     @Test
    public  void testRemovedArchaeologist() {
      excavation.addArchaeologist(Pesho);
      excavation.addArchaeologist(Ivan);
      Assert.assertEquals(true,excavation.removeArchaeologist(Pesho.getName())
      );
      Assert.assertEquals(1,excavation.getCount());
     }
}
